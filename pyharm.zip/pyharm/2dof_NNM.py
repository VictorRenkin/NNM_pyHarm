 ## This block makes the mandatory imports and configure matplotlib for figures
import sys
PATH_TO_PYHARM = False
PATH_TO_PYHARM = "../" ## to be updated
if PATH_TO_PYHARM !=False : 
    sys.path.append(PATH_TO_PYHARM)
# ------------------ IMPORTS ------------------ #
import copy
import numpy as np
import os
import time
import matplotlib.pyplot as plt
import pyHarm
import json
import scipy.io
from pyHarm.Elements.FactoryElements import ElementDictionary
from pyHarm.Elements.ABCElement import ABCElement
import VizData as vd

MassMatrix = np.array([[1.0, 0.0],
                       [0.0, 1]])
DampMatrix = np.array([[0.02, -0.01],
                       [-0.01, 0.02]])
RigidMatrix = np.array([[2, -1],
                        [-1, 2]])
LinSys = dict()
LinSys["M"] = MassMatrix
LinSys["C"] = DampMatrix
LinSys["K"] = RigidMatrix
LinSys["G"] = 0 * MassMatrix


NNMSys = dict()
NNMSys["M"] = MassMatrix
NNMSys["C"] = np.eye(len(MassMatrix))
NNMSys["K"] = RigidMatrix
NNMSys["G"] = 0 * MassMatrix
# ------------------ INPUT CONSTRUCTION ------------------ #
INP = {
    "analysis": {
        "NNM_analysis": {
            "study": "NNM_analysis",
            "phase_condition": "PhaseConditionSimple",
            "puls_inf":0.12 * 2 * np.pi,
            "puls_sup": 0.22 * 2 * np.pi,
            "ds0": 0.01,
            "ds_min": 1e-12,
            "ds_max": 0.01,
            "sign_ds": 1,
            "verbose": False,
            "stepsizer": "acceptance",
            "predictor": "NNM_tangent",
            "predictor_options": {
                "verbose": False
            },
            "corrector": "NNM_pseudo_arc_length",
            "preconditioner": "nopreconditioner",
            "stopper": "solnumber",
            "solver": "NNM_NewtonRaphson"
        }
    },
    "system": {
        "type": "Base",
        "nh": 1,             # number of harmonics to be considered [int]
        "nti": 2048,         # number of time steps.
        "adim": {            # Parameters used for adimensionalising the system [dict[bool,float,float]]
            "status": False, # If True the system will be adimensionalised
            "lc": 1.0,       # length characteristic
            "wc": 1.0        # frequency characteristic
        }
    },
    "substructures": {
        "sub1": {
            "matrix": NNMSys,
            "ndofs": 2
        }
    },
    "connectors": {
        "cubic": {
            "type": "CubicSpring",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "k": 0.5
        }
    }
}


INP_lin = {
    "analysis": {
        "FRF": {
            "study": "frf",
            "puls_inf":0.12 * 2 * np.pi,
            "puls_sup": 0.44 * 2 * np.pi,
            "puls_start":0.13 * 2 * np.pi,
            "ds0": 1e-10,
            "ds_min": 1e-12,
            "ds_max": 1e-2,
            "sign_ds": 1,
            "verbose": False,
            "stepsizer": "acceptance",
            "predictor": "tangent",
            "predictor_options": {
                "verbose": False
            },
            "corrector": "arc_length",
            "preconditioner": "nopreconditioner",
            "stopper": "bounds",
            "solver": "scipyroot"
        }
    },
    "system": {
        "type": "Base",
        "nh": 3,             # number of harmonics to be considered [int]
        "nti": 2048,         # number of time steps.
        "adim": {            # Parameters used for adimensionalising the system [dict[bool,float,float]]
            "status": False, # If True the system will be adimensionalised
            "lc": 1.0,       # length characteristic
            "wc": 1.0        # frequency characteristic
        }
    },
    "substructures": {
        "sub1": {
            "matrix": LinSys,
            "ndofs": 1 # par direction 
        }
    },
    "connectors": {
        "loading": {
            "type": "CosinusForcing",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "amp": 0
        },
        "cubic": {
            "type": "CubicSpring",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "k": 0.5
        }
    }
}

omega_NLFR_1 = []
amplitudes_NLFR_1 = []

omega_NLFR_2 = []
amplitudes_NLFR_2 = []
list_amplitude = np.array([0.002, 0.01, 0.05, 0.1, 0.2])
list_amplitude = np.array([0.002])


for i in range(len(list_amplitude)) :
    INP_lin['connectors']['loading']['amp'] = list_amplitude[i]
    NRB_lin = pyHarm.Maestro(INP_lin)
    indices_selection_1 = ("sub1",0,0) # self, sub:str, node:int, dir_num:int
    indexH_1 = NRB_lin.getIndex(*indices_selection_1)
    indices_selection_2 = ("sub1",1,0) # self, sub:str, node:int, dir_num:int
    indexH_2 = NRB_lin.getIndex(*indices_selection_2)
    NRB_lin.operate()
    SA_lin = [sol for sol in NRB_lin.nls["FRF"].SolList if sol.flag_accepted]
    om_lin = np.array([sol.x[-1] for sol in SA_lin])
    omega_NLFR_1.append(om_lin)
    omega_NLFR_2.append(om_lin)
    elem = NRB_lin.nls["FRF"].system.LE_linear[0]
    print(NRB_lin.nls["FRF"].system.expl_dofs)
    print(NRB_lin.getHarm(1))
    
    SA_lin_X = np.concatenate([sol.x.reshape(-1,1) for sol in SA_lin],axis=1)
    a_max_lin_1 = []
    a_max_lin_2 = []
    print()
    for j in range(len(om_lin)):
        X_TIME_1 = SA_lin_X[indexH_1, j] @ elem.D["ft"]
        # X_TIME_2 = SA_lin_X[indexH_2, j] @ elem.D["ft"]
        a_max_lin_1.append(np.max(X_TIME_1))
        # a_max_lin_2.append(np.max(X_TIME_2))

    amplitudes_NLFR_1.append(a_max_lin_1)
    amplitudes_NLFR_2.append(a_max_lin_2)
    print(f"Finish the NLFR of {list_amplitude[i] : .2f} N")

NRB_NH = pyHarm.Maestro(INP)
indices_selection = ("sub1", 1, 0) 
indexH = NRB_NH.getIndex(*indices_selection) # trouve l'indice 

NRB_NH.operate() # effectue le code

SA = [sol for sol in NRB_NH.nls["NNM_analysis"].SolList if sol.flag_accepted]

om = np.array([sol.x[-1] for sol in SA])
mu = np.array([sol.mu for sol in SA])

elem = NRB_NH.nls["NNM_analysis"].system.LE_nonlinear_nodlft[0] # linear system
SA_X = np.concatenate([sol.x.reshape(-1,1) for sol in SA ],axis=1)
a_max = []

for i in range(len(om)):
    X_TIME = SA_X[indexH,i] @ elem.D["ft"] # temporal a frequenuicel discret fourier transform
    a_max.append(np.max(X_TIME))

plt.figure(figsize=(12, 8))
plt.plot(om, a_max)
plt.show()
print("mu : \n", mu)


# vd.viz_NNM_with_NLFRs(om, a_max, omega_NLFR_1, amplitudes_NLFR_1, list_amplitude, name_figure="NLFR_Vs_NNM_cubicANDsquare")
# plt.figure(figsize=(12, 8))
# for i in range(len(list_amplitude)) : 
#     plt.plot(omega_NLFR_1[i], amplitudes_NLFR_1[i])
# plt.show()

# plt.figure(figsize=(12, 8))
# for i in range(len(list_amplitude)) : 
#     plt.plot(omega_NLFR_2[i], amplitudes_NLFR_2[i])
plt.show()