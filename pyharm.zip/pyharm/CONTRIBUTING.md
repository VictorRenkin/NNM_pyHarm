## Contribution process 

To contribute to the codebase, it is essential to follow a structured process.

 Firstly, create a branch or a remote repository that contains the code, and then create a branch from it. This ensures that modifications are isolated from the main codebase until they are reviewed and approved. 
 
 When making modifications, it is important to adhere to the Google format style for writing docstrings. These docstrings provide clear and concise explanations of the code's functionality, making it easier for others to understand and maintain the code as well as generating the documentation. 
 
 Additionally, it is advantageous to include test scripts or Jupyter notebooks in the `CodeReviewTestFiles` folder, providing a means to verify the code's correctness or showcase its usage during the reviewing process. 
 
 **Before proceeding, it is crucial to ensure that the non-regression test suite runs without any error, ensuring that existing functionality remains intact.**
 
  Finally, when ready, post a merge request to the master branch of the pyHarm repository for review and inclusion into the main codebase.

  | Step | Description |
| ---- | ----------- |
| 1.   | Fork the project, create a branch or a remote repository containing the code and branch from it. |
| 2.   | Make modifications to the code, ensuring adherence to the Google format style for docstrings. |
| 3.   | Optionally, include test scripts or Jupyter notebooks in the CodeReviewTestFiles folder to validate the code or provide examples. |
| 4.   | Verify that the non-regression test suite returns no errors to ensure existing functionality is unaffected. |
| 5.   | Submit a merge/pull request to the master branch of the pyHarm repository for review. |
| 6.   | Reviewers will assess the changes and provide feedback for further improvements, if necessary. |
| 7.   | Once the merge request is approved, the code will be merged into the master branch, incorporating the modifications into the main codebase. |

## Collaborating on Issue Resolution and Project Solving

Addressing and solving issues is highly encouraged in our development process. We have a designated issue folder where various challenges and tasks are listed in the gitlab repository. 

Additionally, the development team often marks their proposed projects with a distinct `[project]` tag in the issue title. These projects represent important tasks or initiatives that would significantly benefit the team if resolved. Tackling and resolving these projects not only helps address specific needs but also contributes to the overall progress and efficiency of the code. Therefore, we highly value and appreciate the efforts put into solving these marked projects, as they can greatly impact the team's success and productivity.

## Contributing Tutorials: Sharing Knowledge and Enhancing Accessibility

We warmly welcome contributions that go beyond issue resolution and project solving. In addition to embracing issue resolution and project solving, we appreciate diverse tutorial contributions for our codebase. 

These tutorials come in two forms: 
- general guides 
- application-specific tutorials 

General tutorials, such as Jupyter notebooks, provide step-by-step instructions and demonstrations for various aspects of our code. They play a crucial role in enhancing the overall accessibility and understanding of our codebase. 

On the other hand, we also encourage the creation of application-specific tutorials that focus on the practical application of our Harmonic Balanced Method-based code for solving structural vibration problems with nonlinearities. These specialized tutorials provide valuable insights and practical guidance for addressing real-world vibration challenges. By sharing expertise in applying our code to specific vibration scenarios, contributors can empower users to confidently analyze and mitigate nonlinear vibration issues. 

All tutorial contributions - both general and application-specific - are highly valued as they contribute to the collaborative and supportive environment we strive to foster.