 ## This block makes the mandatory imports and configure matplotlib for figures
import sys
PATH_TO_PYHARM = False
PATH_TO_PYHARM = "../" ## to be updated
if PATH_TO_PYHARM !=False : 
    sys.path.append(PATH_TO_PYHARM)
# ------------------ IMPORTS ------------------ #
import copy
import numpy as np
import os
import time
import matplotlib.pyplot as plt
import pyHarm
import json
import scipy.io
from pyHarm.Elements.FactoryElements import ElementDictionary
from pyHarm.Elements.ABCElement import ABCElement
import VizData as vd

# ------------------ SYSTEM CONSTRUCTION ------------------ #
m = 1.0 # mass
alpha = 1 # stiffness
beta = 1 # cubic term stiffness
gamma = 1.0 # forcing amplitude

MassMatrix = np.array([[m]])
DampMatrix = np.eye(len(MassMatrix))
RigidMatrix = np.array([[alpha]])
LinSys = dict()
LinSys["M"] = MassMatrix
LinSys["C"] = DampMatrix
LinSys["K"] = RigidMatrix
LinSys["G"] = 0 * MassMatrix

# ------------------ INPUT CONSTRUCTION ------------------ #
INP = {
    "analysis": {
        "NNM_analysis": {
            "study": "NNM_analysis",
            "phase_condition": "PhaseConditionSimple",
            "puls_inf": 0.01,
            "puls_sup": 2.5,
            "ds0": 0.01,
            "ds_min": 1e-12,
            "ds_max": 0.01,
            "sign_ds": 1,
            "verbose": False,
            "stepsizer": "acceptance",
            "predictor": "NNM_tangent",
            "predictor_options": {
                "verbose": False
            },
            "corrector": "NNM_pseudo_arc_length",
            "preconditioner": "nopreconditioner",
            "stopper": "solnumber",
            "solver": "NNM_NewtonRaphson"
        }
    },
    "system": {
        "type": "Base",
        "nh": 7,             # number of harmonics to be considered [int]
        "nti": 2048,            # number of time steps.
        "adim": {            # Parameters used for adimensionalising the system [dict[bool,float,float]]
            "status": False, # If True the system will be adimensionalised
            "lc": 1.0,       # length characteristic
            "wc": 1.0        # frequency characteristic
        }
    },
    "connectors": {
        "cubic": {
            "type": "CubicSpring",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "k": beta
        },
        "square" :{
            "type": "SquareSpring",
            "connect": {
            "sub1": [0]},
            "dirs": [0],
            "k": beta
        }
    },
    "substructures": {
        "sub1": {
            "matrix": LinSys,
            "ndofs": 1
        }
    }
}

m = 1.0 # mass
delta = 0.3 # damping
alpha = 1 # stiffness
beta = 1 # cubic term stiffness
gamma = 1.0 # forcing amplitude

MassMatrix = np.array([[m]])
DampMatrix = np.array([[delta]])
RigidMatrix = np.array([[alpha]])
LinSys = dict()
LinSys["M"] = MassMatrix
LinSys["C"] = DampMatrix
LinSys["K"] = RigidMatrix
LinSys["G"] = 0 * MassMatrix

INP_lin = {
    "analysis": {
        "FRF": {
            "study": "frf",
            "puls_inf": 0.01,
            "puls_sup": 2.5,
            "ds0": 0.01,
            "ds_min": 1e-12,
            "ds_max": 0.01,
            "sign_ds": 1,
            "verbose": False,
            "stepsizer": "acceptance",
            "predictor": "tangent",
            "predictor_options": {
                "verbose": False
            },
            "corrector": "arc_length",
            "preconditioner": "nopreconditioner",
            "stopper": "bounds",
            "solver": "scipyroot"
        }
    },
    "system": {
        "type": "Base",
        "nh": 7,             # number of harmonics to be considered [int]
        "nti": 2048,         # number of time steps.
        "adim": {            # Parameters used for adimensionalising the system [dict[bool,float,float]]
            "status": False, # If True the system will be adimensionalised
            "lc": 1.0,       # length characteristic
            "wc": 1.0        # frequency characteristic
        }
    },
    "substructures": {
        "sub1": {
            "matrix": LinSys,
            "ndofs": 1
        }
    },
    "connectors": {
        "loading": {
            "type": "CosinusForcing",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "amp": gamma
        },
        "cubic": {
            "type": "CubicSpring",
            "connect": {
                "sub1": [0]},
            "dirs": [0],
            "k": beta
        },
        # "square" :{
        #     "type": "SquareSpring",
        #     "connect": {
        #     "sub1": [0]},
        #     "dirs": [0],
        #     "k": beta
        # }
    }
}

omega_NLFR = []
amplitudes_NLFR = []
list_amplitude = np.arange(0.05,0.5,0.1)
for i in range(len(list_amplitude)) :
    INP_lin['connectors']['loading']['amp'] = list_amplitude[i]
    NRB_lin = pyHarm.Maestro(INP_lin)
    indices_selection = ("sub1",0,0) 
    indexH = NRB_lin.getIndex(*indices_selection) # trouve l'indice 
    NRB_lin.operate() # effectue le code
    SA_lin = [sol for sol in NRB_lin.nls["FRF"].SolList if sol.flag_accepted]
    om_lin = np.array([sol.x[-1] for sol in SA_lin])
    omega_NLFR.append(om_lin)

    elem = NRB_lin.nls["FRF"].system.LE_nonlinear_nodlft[0]
    SA_lin_X = np.concatenate([sol.x.reshape(-1,1) for sol in SA_lin],axis=1)
    a_max_lin = []
    for j in range(len(om_lin)):
        X_TIME = SA_lin_X[indexH,j] @ elem.D["ft"] # temporal a frequenuicel discret fourier transform
        a_max_lin.append(np.max(X_TIME))
    amplitudes_NLFR.append(a_max_lin)
    print(f"Finish the NLFR of {list_amplitude[i] : .2f} N")


# INP['analysis']['NNM']['puls_start'] = omega[0]
NRB_NH = pyHarm.Maestro(INP)
indices_selection = ("sub1",0,0) 
indexH = NRB_NH.getIndex(*indices_selection) # trouve l'indice 

# # determine the start x0
# M_inv = np.linalg.inv(LinSys["M"])
# omega ,mode = np.linalg.eig(M_inv @ LinSys["K"])


NRB_NH.operate() # effectue le code

SA = [sol for sol in NRB_NH.nls["NNM_analysis"].SolList if sol.flag_accepted]

om = np.array([sol.x[-1] for sol in SA])
mu = np.array([sol.mu for sol in SA])
om_pred = np.array([sol.x_pred[-1] for sol in SA])

elem = NRB_NH.nls["NNM_analysis"].system.LE_nonlinear_nodlft[0] # linear system
SA_X = np.concatenate([sol.x.reshape(-1,1) for sol in SA ],axis=1)
SA_X_pred = np.concatenate([sol.x_pred.reshape(-1,1) for sol in SA ],axis=1)
a_max = []
pred_a_max = []

for i in range(len(om)):
    X_TIME = SA_X[indexH,i] @ elem.D["ft"] # temporal a frequenuicel discret fourier transform
    a_max.append(np.max(X_TIME))
   

for i in range(len(om_pred)):
    X_pred_TIME = SA_X_pred[indexH,i] @ elem.D["ft"] # temporal a frequenuicel discret fourier transform
    pred_a_max.append(np.max(X_pred_TIME))

vd.viz_NNM_with_NLFRs(om, a_max, omega_NLFR, amplitudes_NLFR, list_amplitude, name_figure="NLFR_Vs_NNM_cubicANDsquare")
print("mu : \n", mu)