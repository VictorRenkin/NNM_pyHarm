# Nonlinear Normal Modes (NNM) – Summary of Additions

This README outlines the recent developments introduced for Nonlinear Normal Modes (NNMs) within the project.

## NNM Analysis

The `Analysis/NNM_Analysis` directory now contains a dedicated module for NNM computation.

Currently, it is compatible only with the following continuation classes:
- `CorrectorNNMPseudoArclength`
- `PredictorNNMTangent`
- `NNMNewtonRaphson`

Using other classes may result in incompatibilities or incorrect behaviour.

---

## Substructure Module

A new attribute `start_kronC` has been added to substructure elements. It is a simple copy of `kronC`, allowing preservation of the original matrix for specific operations.

---

## System Module

Two new functions have been introduced in the `System` class:

### `_get_assembled_damping_matrix(**kwargs)`

This method computes the damping matrix of the assembled system, returning a matrix of the form  
\[
\nabla \otimes I_n
\]  
It assumes that the damping matrix is initially set as an identity matrix. This should be verified at the beginning of the simulation to avoid inconsistencies.

### `update_kronC_with_relaxation_parameter(relaxation_parameter: float)`

This method scales the `kronC` matrix of each substructure element using the given relaxation parameter, without modifying the residual or the Jacobian fonction. This provides a flexible way to introduce a relaxation effect while preserving the integrity of the system’s formulation.

---

## Phase Condition

A new `PhaseCondition` module has been introduced, including two classes:
- `SimpleCondition`: A standard implementation of the phase condition.
- `RobustCondition`: A more stable and general alternative for challenging configurations.



