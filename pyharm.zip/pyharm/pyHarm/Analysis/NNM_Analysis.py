from pyHarm.Analysis.ABCAnalysis import ABCAnalysis
from pyHarm.Solver import FirstSolution,SystemSolution
from pyHarm.Systems.ABCSystem import ABCSystem
import numpy as np
from pyHarm.PhaseCondition.FactoryPhaseCondition import generatePhaseCondition
from pyHarm.Correctors.FactoryCorrector import generateCorrector
from pyHarm.Predictors.FactoryPredictor import generatePredictor
from pyHarm.StepSizeRules.FactoryStepSize import generateStepSizeRule
from pyHarm.StopCriterion.FactoryStopCriterion import generateStopCriterion
from pyHarm.NonLinearSolver.FactoryNonLinearSolver import generateNonLinearSolver
from pyHarm.Reductors.FactoryChainedReductors import generateChainReductor
from pyHarm.BaseUtilFuncs import getCustomOptionDictionary
import copy
from scipy import linalg

class NNM_Analysis(ABCAnalysis):
    """Nonlinear Normal Mode analysis.

    Predicts a starting point using the predictor and then solves the residual equations from the starting point.
    
    Attributes:
        flag_print (bool): if True, prints a message after each Solve method.
        flag_purge (bool): if True, the jacobian values are purged from the solutions stored in the solution list.
        analysis_options (dict): input dictionary completed with the default values if keywords are missing.
        ds (float): initial prediction step size.
        SolList (list[SystemSolution]): list of SystemSolution stored after each Solve method.
        system (ABCSystem): ABCSystem associated with the analysis.
        adaptstep (ABCStepSizeRule): ABCStepSizeRule associated with the analysis.
        predictor (ABCPredictor): ABCPredictor associated with the analysis.
        corrector (ABCCorrector): ABCCorrector associated with the analysis.
        stopper (ABCStopCriterion): ABCStopCriterion associated with the analysis.
        solver (ABCNLSolver): ABCNLSolver associated with the analysis.
        corrector_init (ABCCorrector): instance of no-continuation corrector for initial solution.
        reductor (ABCChainedReductor): ABCChainedReductor associated with the analysis.
    """
    
    factory_keyword : str = "NNM_analysis"
    """str: keyword that is used to call the creation of this class in the system factory."""

    name = "Nonlinear Normal Mode analysis"

    default={   "study":"NNM",
                "solver":"NewtonRaphson",
                "predictor":"tangent",
                "corrector":"arc_length",
                "preconditioner":"nopreconditioner",
                "reductors":[{"type":"noreductor"}],
                "stepsizer":"acceptance",
                "stopper":"bounds",
                "ds_max":1e0,"ds_min":1e-8,"ds0":1e0,
                "sign_ds":1,
                "puls_inf":.1,"puls_sup":1.0,
                "verbose":True,
                "purge_jacobians":True,
                "mode_selected":0,
                "scaling_mode":1e9,
                "mu_start":0
                }
    """dict: default dictionary for the analysis."""
    
    def __init__(self, inputData:dict, System:ABCSystem, **kwargs):
        self.analysis_options = getCustomOptionDictionary(inputData,self.default)
        self.flag_print = self.analysis_options["verbose"]
        self.flag_purge = self.analysis_options["purge_jacobians"]
        self.ds = self.analysis_options["ds0"]
        self.SolList = []
        ### Base objects :
        self.system = System
        self.adaptstep = generateStepSizeRule(self.analysis_options["stepsizer"],\
                                             [self.analysis_options['ds_min'],self.analysis_options['ds_max']],\
                                             self.analysis_options.get("stepsize_options",dict()))
        self.predictor = generatePredictor(self.analysis_options["predictor"], self.analysis_options["sign_ds"], self.analysis_options.get("predictor_options",dict()))
        self.corrector = generateCorrector(self.analysis_options["corrector"],self.analysis_options.get("corrector_options",dict()))
        self.stopper   = generateStopCriterion(self.analysis_options["stopper"],\
                                             [self.analysis_options['puls_inf'],self.analysis_options['puls_sup']],\
                                             self.analysis_options['ds_min'],\
                                             self.analysis_options.get("stopper_options",dict()))
        self.solver    = generateNonLinearSolver(self.analysis_options["solver"],\
                                             self.globalResidual, self.globalJacobian,\
                                             self.analysis_options.get("solver_options",dict()))
        self.corrector_init = generateCorrector("NNM_nocontinuation",self.analysis_options.get("corrector_options",dict()))
        self.reductor       = generateChainReductor(self.analysis_options["reductors"],
                                              self.system._get_expl_dofs_into_solver())
        self.phase_condition = generatePhaseCondition(self.analysis_options["phase_condition"],self.analysis_options.get("phase_condition_options",dict()))

    def initialise(self, **kwargs):
        """
        First Solve on the initial guess this is the LNM of the system.

        Args:
            x0 (None|str|np.ndarray): if None x0 is the linear solution at initial angular frequency, if "null" x0 is null vector, otherwise x0 is initialised using the provided array.
        """
        omega_sorted_square, phi_sorted = self.get_eigenvector_eigenfrequency()
        phi_sorted = phi_sorted/np.max(phi_sorted) * self.analysis_options["scaling_mode"]
        x0 = np.zeros(self.system.ndofs_solve + 1)
        mode_apply = self.analysis_options["mode_selected"]
        harm_apply = 1 # cos of the first harmonic
        index_harm_c = self.getHarm(harm_apply, ['c'])
        x0[index_harm_c] = phi_sorted[:, mode_apply]
        x0[-1] = np.sqrt(omega_sorted_square[mode_apply])
        self.x0 = x0
        isol = FirstSolution(self.x0)
        mu = self.analysis_options["mu_start"]
        self.CompleteFirstSolution(self.x0, mu, isol)
        
    def get_eigenvector_eigenfrequency(self) :
        x0 = np.concatenate([np.zeros(self.system.ndofs_solve), np.array([0.])])
        M_assembled = self.system._get_assembled_mass_matrix(x0)
        if len(self.system.LE_nonlinear_dlft) != 0 :
            Rlin = np.zeros(self.system.ndofs)
            Rlin += self.system._residual(self.system.LE_extforcing,x0)
            Rlin += self.system._residual(self.system.LE_linear,x0)
            K_assembled = self.system._get_assembled_stiffness_matrix(x0,**{"Rglin":Rlin,"dJgdxlin":None,"dJgdomlin":None})
        else:
           K_assembled = self.system._get_assembled_stiffness_matrix(x0) 
        size_K = np.shape(K_assembled)[0] // (2*self.system.nh+1)
        K_global =  K_assembled[size_K:2*size_K, size_K:2*size_K]
        M_global =  M_assembled[size_K:2*size_K, size_K:2*size_K]
        
        w, phi = linalg.eig(K_global, M_global)  
        w = np.real(w)     
        phi = np.real(phi)
        indices_sorted = np.argsort(w)
        omega_sorted = w[indices_sorted]
        phi_sorted = phi[indices_sorted]

        return omega_sorted, phi_sorted
    
    def getHarm(self, harm_selected, cs=['c', 's']):
        """
        Returns the indices of the degrees of freedom corresponding to the selected harmonic
        and the specified cosine/sine components.
        """
        expl_dofs = self.system.expl_dofs

        # Filtrage sur l'harmonique sélectionné
        harm_mask = expl_dofs["harm"] == harm_selected

        # Filtrage sur les composantes cos/sin
        cs_mask = expl_dofs["cs"].isin(cs)

        # Filtrage combiné
        selected = expl_dofs[harm_mask & cs_mask]

        return np.sort(selected.index)
    
    def CompleteFirstSolution(self, solx:np.ndarray, solmu:np.ndarray, sol:SystemSolution) :
        sol.index_insolve = 0 
        sol.iter_numb = 0
        sol.status_solver = 1
        sol.x = sol.x
        sol.fictive_energy = self.phase_condition.get_Energy_fictive(sol.x, self.system)
        sol.mu = solmu
        sol.flag_R = True 
        sol.flag_J = True
        sol.flag_J_f = True 
        dR_change = None
        sol.flag_intosolver = True
        sol.flag_accepted = True
        sol.R = self.globalResidual(sol.x, sol.mu, sol)
        sol.J_f = self.globalJacobian(sol.x, sol.mu, sol)
        sol.SaveSolution(self.SolList)
        self.initialise_dir(sol, np.ones_like(sol.x[:-1]), np.zeros_like(sol.x[-1]), -1)
        sol.mu = solmu
        sol.mu_pred = sol.mu

    def initialise_dir(self, sol:SystemSolution, tan_u:np.ndarray, tan_w:np.ndarray, tan_mu:np.ndarray) :
        sol.dir = np.zeros_like(sol.x)
        sol.dir[:-1] = tan_u
        sol.dir[-1] = tan_w
        sol.dir_mu = tan_mu


    def CompleteSolution(self,sol:SystemSolution, mu, **kwargs):
        """
        Completes a SystemSolution informations that just went out of the Solve method.

        Args:
            sol (SystemSolution): solution to the system.
        """
        sol.x = sol.x
        sol.fictive_energy = self.phase_condition.get_Energy_fictive(sol.x, self.system)
        sol.mu = mu
        sol.flag_R = True 
        sol.flag_J = True
        sol.flag_J_f = True 
        dR_change = None
        sol.R = self.globalResidual(sol.x, sol.mu, sol)
        sol.J_f = self.globalJacobian(sol.x, sol.mu, sol)



    def globalResidual(self, solx:np.ndarray, solmu:np.ndarray, sol:SystemSolution):
        """
        Computes the residual of the whole system without the reducers.

        Args:
            solx (np.ndarray): displacement vector for which residual is computed.
            sol (SystemSolution): actual SystemSolution being solved.
        """
        self.system.update_kronC_with_relaxation_parameter(solmu)
        # Get the Residual of the system at point x
        Rg = self.system.Residual(solx)
        # Get the corrector closure equation
        if isinstance(sol,FirstSolution) :
            R_cont = self.corrector_init.ClosureEquation(solx, sol, self.SolList)
        else : 
            R_cont = self.corrector.ClosureEquation(solx, sol, self.SolList, solmu=solmu)

        Rp = self.phase_condition.ClosureEquation(solx, sol)


        # Assembly of the matrix
        Rg = np.concatenate((Rg, np.asarray([Rp, R_cont])))
        return Rg

    def globalJacobian(self, solx:np.ndarray, solmu:np.ndarray, sol:SystemSolution):
        """
        Computes the jacobians of the whole system without the reducers.

        Args:
            solx (np.ndarray): displacement vector for which residual is computed.
            sol (SystemSolution): actual SystemSolution being solved.
        """
        self.system.update_kronC_with_relaxation_parameter(solmu)
        # Get the Jacobian of the system at point x
        [dJdx, dJdom] = self.system.Jacobian(solx)
        dJdmu = self.phase_condition.get_Energy_fictive(solx, self.system)
        # Get the corrector Jacobian of closure equation
        if isinstance(sol, FirstSolution):
            [dRdx, dRdom, dRdmu] = self.corrector_init.ClosureJacobian(solx, sol, self.SolList)
        else:
            [dRdx, dRdom, dRdmu] = self.corrector.ClosureJacobian(solx, sol, self.SolList)
        # Get the phase condition Jacobian
        [dPdx, dPdom, dPmu] = self.phase_condition.ClosureJacobian(solx, sol)

        Jg = np.block([
            [dJdx,  dJdom,  dJdmu],
            [dPdx,  dPdom,  dPmu],
            [dRdx,  dRdom,  dRdmu]
        ])

        return Jg
    

    def makeStep(self,**kwargs) :
        """
        Makes a step of solving : get a step size, generate a predicted point, solve the nonlinear system, save the solution.
        """
        print("Make step")
        # obtain the starting point 
        self.ds = self.adaptstep.getStepSize(self.ds,self.SolList)
        xpred_full, mu_pred, dir, dir_mu, last_solution_pointer = self.predictor.predict(self.SolList,self.ds)
        sol = SystemSolution(xpred_full,last_solution_pointer) 
        sol.ds = self.ds
        sol.mu = mu_pred
        sol.mu_pred = np.zeros_like(mu_pred)
        sol.dir = dir
        sol.dir_mu = dir_mu
        # print("dir", dir)
        # print("dir_mu", dir_mu)
        # exit()
        sol.fictive_energy = self.phase_condition.get_Energy_fictive(xpred_full, self.system)
        sol = self.solver.Solve(sol, self.SolList)
        self.CompleteSolution(sol, sol.mu)
        if "index_insolve" in kwargs : 
            sol.index_insolve = kwargs["index_insolve"]
        sol.SaveSolution(self.SolList)
        if self.flag_print :
            if sol.flag_accepted :
                print("solution converged at om={}".format(sol.x[-1]))
            else :
                print("solution not accepted at om={}".format(sol.x[-1]))
        pass

    def Solve(self, x0, **kwargs):
        """
        Makes the whole analysis using continuation techniques until the stopping criterion is validated

        Args:
            x0 (None|str|np.ndarray): if None x0 is the linear solution at initial angular frequency, if "null" x0 is null vector, otherwise x0 is initialised using the provided array.
        """
        self.initialise(**kwargs)
        k=1
        while not self.stopper.getStopCriterionStatus(self.SolList[-1],self.SolList) : 
            self.makeStep(index_insolve=k)
            self.purge_jacobians()
            k+=1
        pass

    def purge_jacobians(self,):
        """Purge the Jacobians of Solutions that are no longer used."""
        def purge(SA) : 
            for sol in SA:
                sol.J_f = None
                sol.J_lu = None
                sol.J_qr = None
                sol.flag_J = False
                sol.flag_J_qr = False # Jacobian available with qr formalism of scipy.linalg.qr=[Q,R]
                sol.flag_J_lu = False # Jacobian available with lu formalism of scipy.linalg.lu=[P,L,U]
                sol.flag_J_f = False # Jacobian available full size

        if not self.flag_purge : 
            pass
        else : 
            acc_sols = [sol for sol in self.SolList if ((sol.flag_accepted) and (sol.flag_J))]
            nonacc_sols = [sol for sol in self.SolList if ((not sol.flag_accepted) and (sol.flag_J))]
            purge(acc_sols[:-2])
            purge(nonacc_sols)