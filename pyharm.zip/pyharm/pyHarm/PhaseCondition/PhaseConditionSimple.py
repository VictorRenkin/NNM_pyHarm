from pyHarm.PhaseCondition.ABCPhaseCondition import ABCPhaseCondition
import numpy as np
from pyHarm.Systems.ABCSystem import ABCSystem
from pyHarm.Solver import SystemSolution

class PhaseConditionSimple(ABCPhaseCondition):
    """
    Enforces a phase condition by fixing a specific degree of freedom
    at a given harmonic and node at 0. This eliminates phase invariance 
    in the solution, ensuring uniqueness.
    """
    factory_keyword: str = "PhaseConditionSimple"
    def ClosureEquation(self, solx: np.ndarray, sol: SystemSolution) -> np.ndarray:
        """
        Apply this phase condition on the first node on the cosinus of the first harmonic.
        """
        if len(solx) > 1: 
            return solx[2]
        else:
            raise ValueError("Need one harmonic mimimum to apply the phase condition.")
    

    def ClosureJacobian(self, solx: np.ndarray, sol: SystemSolution) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute the Jacobian of the closure equation.
        """
        if len(solx) > 1:
            dpdx = np.zeros((1, len(solx[:-1])))
            dpdx[0][2] = 1
            dpdom = 0
            dpdmu = 0
            return dpdx, dpdom, dpdmu
        else:
            raise ValueError("Need one harmonic mimimum to apply the phase condition.")

