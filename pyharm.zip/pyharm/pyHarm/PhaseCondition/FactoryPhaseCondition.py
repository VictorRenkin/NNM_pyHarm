"""
This module contains the factory of the phase condition objects. 

Attributes:
    PhaseCondition_dico (dict): Dictionary that contains ABCPhaseCondition objects as values and their factory_keyword attribute as their key.
"""
from pyHarm.PhaseCondition.PhaseConditionSimple import PhaseConditionSimple
from pyHarm.PhaseCondition.ABCPhaseCondition import ABCPhaseCondition
from pyHarm.PhaseCondition.PhaseConditionRobust import PhaseConditionRobust

PhaseCondition_dico = {PhaseConditionSimple.factory_keyword: PhaseConditionSimple,
                       PhaseConditionRobust.factory_keyword: PhaseConditionRobust}

def generatePhaseCondition(name_phasecondition, phasecondition_options) -> ABCPhaseCondition:
    if name_phasecondition in PhaseCondition_dico:
        return PhaseCondition_dico[name_phasecondition](**phasecondition_options)
    else:
        raise ValueError(f"Unknown PhaseCondition: {name_phasecondition}")