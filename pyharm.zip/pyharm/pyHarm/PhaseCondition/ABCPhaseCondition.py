import abc
import numpy as np
from pyHarm.Systems.ABCSystem import ABCSystem
from pyHarm.Solver import SystemSolution

class ABCPhaseCondition(abc.ABC):
    """This is the abstract class ruling the corrector class. The system is responsible for adding the correction residual equation to the augmented system.
    
    """
    @property
    @abc.abstractmethod
    def factory_keyword(self)->str:
        """
        str: name of the class to call in the factory in order to create an instance of the class.
        """
        ...
    
    def __init__(self,**kwargs):
        pass

    
    def get_Energy_fictive(self, solx:np.ndarray, system:ABCSystem) -> np.ndarray:
        """
        Return the fictitious energy vector.
        e_fic = (∇ ⊗ Iₙ) * ũᵢ
        Args:
            solx (np.ndarray): actual displacement vector.
            system (ABCSystem): system that contains kronC.

        Returns:
            E_fic_vec: Fictitious energy vector (same shape as vec_u)
        """
        C_assembled = system._get_assembled_damping_matrix() * solx[-1]
        fictive_energy =  C_assembled @ solx[:-1]
        return fictive_energy.reshape(len(fictive_energy),1)

        

    @abc.abstractmethod
    def ClosureJacobian(self, solx:np.ndarray, sol:SystemSolution) -> tuple[np.ndarray,np.ndarray, np.ndarray]:
        """Computes the jacobian contribution of the correction equation.

        Args:
            solx (np.ndarray): actual displacement vector.
            sol (SystemSolution): actual SystemSolution that contains the starting point.
            sollist (list[SystemSolution]): list of SystemSolutions from previous analysis steps.
        """
        pass

    @abc.abstractmethod
    def ClosureEquation(self, solx:np.ndarray, sol:SystemSolution) -> np.ndarray:
        """Computes the residual contribution of the correction equation.

        Args:
            solx (np.ndarray): actual displacement vector.
            system (ABCSystem): system that contains kronC.
            fictive_energy (float): fictive energy value.

        Returns:
            np.ndarray: residual vector.
        """
        pass