from pyHarm.PhaseCondition.ABCPhaseCondition import ABCPhaseCondition
import numpy as np
from pyHarm.Systems.ABCSystem import ABCSystem
from pyHarm.Solver import SystemSolution

class PhaseConditionRobust(ABCPhaseCondition):
    """
    Implements the robust phase condition:
        p(ũ) = ũᵀ_{i-1} (∇ ⊗ Iₙ) ũᵢ
    where ũᵢ and ũ_{i-1} are, respectively, the current and previous solutions.
    """
    factory_keyword: str = "PhaseConditionRobust"
    def ClosureEquation(self, solx: np.ndarray, sol: SystemSolution) -> np.ndarray:
        """
        Residual part :
            p(ũ) = ũᵀ_{i-1} (∇ ⊗ Iₙ) ũᵢ
        """
        return float(sol.fictive_energy.T @ solx[:-1])
    

    def ClosureJacobian(self, solx: np.ndarray, sol: SystemSolution) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute the derivative of the phase condition with respect to the displacement vector `u`.
            ∇₍ᵤ₎ p = ũᵀ_{i-1} (∇ ⊗ Iₙ)
        """
        dpdx  = sol.fictive_energy.T
        dpdom = 0
        dpdmu = 0
        return dpdx, dpdom, dpdmu