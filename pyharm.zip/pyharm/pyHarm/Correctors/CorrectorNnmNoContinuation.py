from pyHarm.Correctors.ABCCorrector import ABCCorrector
import numpy as np
from pyHarm.Solver import SystemSolution


class Corrector_NNM_no_continuation(ABCCorrector):
    """
    Corrector corresponding to the no continuation method where the equations are solved for a fixed angular frequency.
    """

    factory_keyword : str = "NNM_nocontinuation"
    """str: name of the class to call in the factory in order to create an instance of the class."""

    def ClosureEquation(self, solx:np.ndarray,sol:SystemSolution,sollist:list[SystemSolution],**kwargs) -> np.ndarray:
        """Computes the residual contribution of the correction equation.

        Args:
            solx (np.ndarray): actual displacement vector.
            sol (SystemSolution): actual SystemSolution that contains the starting point.
            sollist (list[SystemSolution]): list of SystemSolutions from previous analysis steps.

        Returns:
            np.ndarray: Residual of the correction equation.
        """
        R_cont =  solx[-2] - sol.x_start[-2]
        return R_cont

    def ClosureJacobian(self, solx:np.ndarray,sol:SystemSolution,sollist:list[SystemSolution],**kwargs) -> tuple[np.ndarray,np.ndarray]:
        """Computes the jacobian contribution of the correction equation.

        Args:
            solx (np.ndarray): actual displacement vector.
            sol (SystemSolution): actual SystemSolution that contains the starting point.
            sollist (list[SystemSolution]): list of SystemSolutions from previous analysis steps.

        Returns:
            tuple[np.ndarray,np.ndarray]: Jacobians of the correction equation.
        """

        dRdx =  (np.zeros_like(solx[:-1])).T 
        dRdom =  1.  
        dRdmu =  0.
        return dRdx, dRdom, dRdmu