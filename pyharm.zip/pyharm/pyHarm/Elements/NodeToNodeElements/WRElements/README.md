# WRElements subpackage

This subpackage implements a formulation of element that differs from the classical elements using Weighted Residual method.

## WRElement 

To be completed when implemented