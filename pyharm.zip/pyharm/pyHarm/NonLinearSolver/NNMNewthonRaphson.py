# Copyright 2024 SAFRAN SA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyHarm.NonLinearSolver.ABCNonLinearSolver import ABCNLSolver
import copy
import numpy as np
from pyHarm.Solver import FirstSolution,SystemSolution
from pyHarm.BaseUtilFuncs import getCustomOptionDictionary


class Solver_NNM_NewtonRaphson(ABCNLSolver):
    """This nonlinear solver is an implementation of iterative Newton Raphson solving procedure.
    
    Attributes:
        factory_keyword (str): keyword that is used to call the creation of this class in the system factory.
        solver_options (dict): dictionary containing other options for creation of the solver class.
        residual (Callable): function that returns the residual vector of the system to be solved.
        jacobian (Callable): function that returns the jacobian matrix of the system to be solved.
        solver_options_root (dict): dictionary containing options for the root function.
        extcall (Callable): root function of scipy.optimize.
    """
    
    factory_keyword : str = "NNM_NewtonRaphson"
    """str: keyword that is used to call the creation of this class in the system factory."""

    default = {"tol_residual":1e-8          ,
               "tol_delta_x" :1e-8          ,
               "max_iter"    :50            } # Maximum iterations accepted before confirming divergence
    """dict: dictionary containing the default solver_options"""


    def __post_init__(self):
        from scipy.linalg import solve as solve
        self.linearsolve = solve
        self.solver_options = getCustomOptionDictionary(self.solver_options,self.default)
               
    def Solve(self,sol:SystemSolution,SolList:list) -> SystemSolution:
        """
        Runs the solver.

        Args:
            sol (SystemSolution): SystemSolution that contains the starting point.
            SolList (SystemSolution): list of previously solved solutions.
        
        Returns:
            sol (SystemSolution): SystemSolution solved and completed with the output information.
        """
        self.x = sol.x_start
        self.xprec = sol.x_start
        self.mu = sol.mu
        self.muprec = sol.mu
        self.FXk = self.residual(sol.x_start, sol.mu, sol)
        self.AXk = self.jacobian(sol.x_start, sol.mu, sol)
        self.iter = 0
        self.status = 1
        print("Iteration {} : residual norm = {}, delta x norm = {}".format(self.iter, np.linalg.norm(self.FXk), np.linalg.norm(self.x - self.xprec)))

        while ((np.linalg.norm(self.FXk)>=self.solver_options["tol_residual"]) or\
             (np.linalg.norm(self.x - self.xprec)>=self.solver_options["tol_delta_x"])):
            if self.iter != 0 :
                print("Iteration {} : residual norm = {}, delta x norm = {}".format(self.iter, np.linalg.norm(self.FXk), np.linalg.norm(self.x - self.xprec)))

            delta_x, delta_w, delta_mu = self.bordering_3X3_solver(self.AXk, self.FXk)
            # print("self.AXk", self.AXk, "self.FXk", self.FXk)
            self.xprec = copy.deepcopy(self.x)
            self.x -= np.concatenate([delta_x, [delta_w]])
            self.mu -= delta_mu
            self.FXk = self.residual(self.x, self.mu, sol)
            self.AXk = self.jacobian(self.x, self.mu, sol)
            self.iter+=1
            if self.iter>=self.solver_options["max_iter"]:
                self.status=5
                self.CompleteSystemSolution(sol,SolList)
                return sol
        self.CompleteSystemSolution(sol,SolList) # misse a jour de la jacobienne ici 
        return sol


    def CompleteSystemSolution(self, sol, SolList):
        """
        Function that allows to retrieve information of interest

        Args:
            sol (SystemSolution): SystemSolution that contains the starting point.
            SolList (SystemSolution): list of previously solved solutions.
        """
        sol.x_red = copy.deepcopy(self.x)
        sol.R_solver = copy.deepcopy(self.FXk)
        sol.iter_numb = self.iter
        sol.flag_R = True 
        sol.flag_J = True
        sol.flag_J_f = True
        sol.J_f = self.jacobian(sol.x, sol.mu, sol)
        sol.flag_intosolver = True
        if self.status == 1:
            sol.flag_accepted = True
        sol.status_solver = self.status


    def linSysdeltak(self):
        """
        Calculation of the 'deltak' correction to apply to the current iteration in order to converge towards the solution.

        Returns:
            self.extcall_newton(matA,matB): Correction 'deltak'
        """
        return self.linearsolve(self.AXk,self.FXk)
    
    def bordering_3X3_solver(self, A, b):
        """
        Function that allows to solve the linear system Ax = b.
        """
        # Create this form  :
        # [ A   D   G ] [x]   [J]
        # [ Bᵗ  e   h ] [y] = [k]
        # [ Cᵗ  f   i ] [z]   [l]

        Jac = A[:-2,:-2]
        D = A[:-2, -2]
        G = A[:-2, -1]
        B = A[-2, :-2]
        e = A[-2, -2]
        h = A[-2, -1]
        C = A[-1, :-2]
        f = A[-1, -2]
        i = A[-1, -1]
        J = b[:-2]
        k = b[-2]
        l = b[-1]

        X_1 = self.linearsolve(Jac, J)
        X_2 = self.linearsolve(Jac, D)
        X_3 = self.linearsolve(Jac, G)

        a_11 = e - np.dot(B, X_2)
        a_12 = h - np.dot(B, X_3)
        a_21 = f - np.dot(C, X_2)
        a_22 = i - np.dot(C, X_3)

        b_1 = k - np.dot(B, X_1)
        b_2 = l - np.dot(C, X_1)

        y, z = self.linearsolve(np.array([[a_11, a_12], [a_21, a_22]]), np.array([b_1, b_2]))

        X = X_1 - X_2 * y - X_3 * z
        return X, y, z