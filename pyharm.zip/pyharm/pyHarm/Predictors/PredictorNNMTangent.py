# Copyright 2024 SAFRAN SA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyHarm.Predictors.ABCPredictor import ABCPredictor
from pyHarm.Solver import FirstSolution, SystemSolution
from pyHarm.BaseUtilFuncs import getCustomOptionDictionary
import numpy as np
import scipy.linalg as spl
from scipy.linalg import solve as solve

class PredictorNNMTangent(ABCPredictor):
    """Define the tangent type of predictor. Using the Jacobian at solution point, a tangent to R(x)=0 solution is drawn and used as a prediction direction.

    The tangent is computed using a QR decomposition of the Jacobian at the solution point.
    """
    predictor_name = "Tangent Predictor"
    factory_keyword : str = "NNM_tangent"
    """str: keyword that is used to call the creation of this class in the system factory."""
    
    def predict(self, sollist:list[SystemSolution], ds:float, k_imposed=None) -> tuple[np.ndarray,SystemSolution,float]:
        """Predicts the next starting point using the tangent.

        Args:
            sollist (list[SystemSolution]): list of SystemSolution already solved during the analysis.
            ds (float): step size for the prediction.
            k_imposed (None | int): if not None, uses the k_imposed as the index of the last solution pointer.

        Returns:
            np.ndarray: next predicted starting point.
            SystemSolution: last accepted point in the list of solutions.
            float: sign of the prediction used (-1 | 1)
        """
        

        ### Get pointer to solution, Jacobian in full mode, and bifurcation detection
        lstpt = self.getPointerToSolution(sollist,k_imposed) # get pointer
        lstpt.getJacobian("full") # get J_f
        Jac_tan = lstpt.J_f.copy() 
        Jac_tan[-1][:len(lstpt.x)] = lstpt.dir
        Jac_tan[-1][-1] = lstpt.dir_mu
        print("X before", lstpt.x)
        b = np.concatenate([np.zeros_like(lstpt.x[:-1]), [0, 1]])
        dir_x, dir_w, dir_mu = self.bordering_3X3_solver(Jac_tan, b)


        # Normalize the direction vector
        norm = np.sqrt(np.linalg.norm(dir_x)**2 + dir_w**2 + dir_mu**2)
        dir_x = dir_x / norm
        dir_w = dir_w / norm
        dir_mu = dir_mu / norm
        dir = np.concatenate([dir_x, [dir_w]])
        xpred = lstpt.x + dir * ds
        mu_pred = lstpt.mu + dir_mu * ds
        # how he know where the w is ?         
        ## write some stuff in the solution
        lstpt.dir = dir
        lstpt.dir_mu = dir_mu
        lstpt.x_pred = xpred
        lstpt.mu_pred = mu_pred
        # lstpt.sign_ds = self.sign_ds
        return xpred, mu_pred, dir, dir_mu, lstpt
    
    def bordering_3X3_solver(self, A, b):
        """
        Function that allows to solve the linear system Ax = b.
        """
        # Create this form  :
        # [ A   D   G ] [x]   [J]
        # [ Bᵗ  e   h ] [y] = [k]
        # [ Cᵗ  f   i ] [z]   [l]

        Jac = A[:-2,:-2]
        D = A[:-2, -2]
        G = A[:-2, -1]
        B = A[-2, :-2]
        e = A[-2, -2]
        h = A[-2, -1]
        C = A[-1, :-2]
        f = A[-1, -2]
        i = A[-1, -1]
        J = b[:-2]
        k = b[-2]
        l = b[-1]

        X_1 = solve(Jac, J)
        X_2 = solve(Jac, D)
        X_3 = solve(Jac, G)

        a_11 = e - np.dot(B, X_2)
        a_12 = h - np.dot(B, X_3)
        a_21 = f - np.dot(C, X_2)
        a_22 = i - np.dot(C, X_3)

        b_1 = k - np.dot(B, X_1)
        b_2 = l - np.dot(C, X_1)

        y, z = solve(np.array([[a_11, a_12], [a_21, a_22]]), np.array([b_1, b_2]))

        X = X_1 - X_2 * y - X_3 * z
        return X, y, z