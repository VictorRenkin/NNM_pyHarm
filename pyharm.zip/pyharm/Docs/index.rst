.. pyHarm documentation master file, created by
   sphinx-quickstart on Thu Jan 25 18:00:07 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyHarm's documentation!
==================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:


.. include:: ../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: How to install

   HowToInstall

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: How to contribute

   Contributions
   WhatIsNew

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: pyHarm package

   pyHarm
   autoapi/index

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: Tutorials

   tutorials

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
