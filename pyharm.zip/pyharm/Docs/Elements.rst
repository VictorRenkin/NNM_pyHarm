.. pyHarm documentation master file, created by
   sphinx-quickstart on Thu Jan 25 18:00:07 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents
   :hidden:

   api_links

   
Elements package
================


.. include:: ../pyHarm/Elements/README.md
   :parser: myst_parser.sphinx_

Elements subpackages
--------------------
Depending on their application onto the system, multiple types of elements are derived from the introduced package. The types of elements are contained in the following subpackage :

.. toctree::
   :maxdepth: 1
   :caption: Types of elements

   SubstructureMatrixElements
   NodeToNodeElements

.. rubric:: API links

:py:mod:`pyHarm.Elements`
