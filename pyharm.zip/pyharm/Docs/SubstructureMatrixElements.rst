.. toctree::
   :maxdepth: 2
   :caption: Table of Contents
   :hidden:

   api_links

   
SubstructureMatrixElements package
==================================


.. include:: ../pyHarm/Elements/SubstructureMatrixElements/README.md
   :parser: myst_parser.sphinx_


.. rubric:: API links

:py:mod:`pyHarm.Elements.SubstructureMatrixElements`