.. toctree::
   :maxdepth: 2
   :caption: Table of Contents


SubsDataReader package
======================

.. include:: ../pyHarm/Substructures/SubDataReader/README.md
   :parser: myst_parser.sphinx_

   
.. rubric:: API links

:py:mod:`pyHarm.Substructures.SubDataReader`