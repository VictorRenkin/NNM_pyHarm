.. toctree::
   :maxdepth: 2
   :caption: Table of Contents


Substructures package
=====================

.. include:: ../pyHarm/Substructures/README.md
   :parser: myst_parser.sphinx_

Reader subpackage
-----------------

pyHarm uses external file readers in order to parse and adapt input dictionary in the pyHarm syntax. The subpackage responsible of this is decribed below :

.. toctree::
   :maxdepth: 1
   :caption: Data reader

   Substructures_DataReader
   

   
.. rubric:: API links

:py:mod:`pyHarm.Substructures`
