import matplotlib.pyplot as plt
import numpy as np

# Définition globale des paramètres de police et de taille pour tous les graphiques
plt.rc('font', family='serif')  # Police avec empattements, comme Times
plt.rc('text', usetex=True)  # Utiliser LaTeX pour le texte dans les figures
plt.rcParams.update({
    'font.size': 18,         # Taille générale de la police
    'legend.fontsize': 18,   # Taille de la police des légendes
    'axes.labelsize': 18,    # Taille de la police des étiquettes des axes
    'axes.titlesize': 14,    # Taille de la police pour les titres des axes
    'xtick.labelsize': 14,   # Taille de la police pour les graduations de l'axe des X
    'ytick.labelsize': 14,   # Taille de la police pour les graduations de l'axe des Y
    'text.usetex': True,     # Confirmer l'utilisation de LaTeX pour tout le texte
    'figure.titlesize': 18   # Taille de la police pour les titres des figures
})

color_list = [
    "#6e343d", "#007070", "#f07f3c", "#5b57a2", "#7db928", "#e62d31",
    "#005ca9", "#00843b", "#f8aa00", "#5b257d", "#8c8b82"
]

def viz_NNM_with_NLFRs(NNM_om, NNM_amplitude, NLFRs_om, NLFRs_amplitude, NLFR_force, path ="figures/", name_figure="NNM_vs_NLFRs.pdf") : 
    plt.figure(figsize=(12, 8))
    plt.plot(NNM_om, NNM_amplitude, label=r"NNM", color=color_list[0])
    if len(NLFRs_om) != 0 :
        for i in range(len(NLFRs_om)):
            om = NLFRs_om[i]
            amp = NLFRs_amplitude[i]
            force = NLFR_force[i]

            plt.plot(om, amp,
                    label=rf"NLFR : {force:.2f} N",
                    color=color_list[(i + 1)])

            # Trouver le maximum de l'amplitude et sa fréquence correspondante
            idx_max = np.argmax(amp)
            om_max = om[idx_max]
            amp_max = amp[idx_max]

            # Tracer le point du maximum
            plt.scatter(om_max, amp_max,
                        color=color_list[(i + 1)],
                        marker='o', edgecolor='black', zorder=5)
        plt.xlim(np.min(NLFRs_om[0]), np.max(NLFRs_om[0]))
    plt.ylim(np.min(NNM_amplitude), np.max(NNM_amplitude) + np.max(NNM_amplitude)/20)
    plt.xlabel(r"Frequency [rad/s]")
    plt.ylabel(r"Amplitude [m]")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path+name_figure+".pdf", bbox_inches="tight", dpi=300)
    plt.show()
    plt.close()
